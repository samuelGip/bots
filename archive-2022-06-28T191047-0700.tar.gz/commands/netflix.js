const Discord = require("discord.js")
const fs = require("fs")
const config = require("../config.json")
const talkedRecently = new Set();

exports.run = (client, message, args) => {
  const vipbed = new Discord.MessageEmbed()
  vipbed.setColor("ff0303")
  vipbed.setDescription(`<:denied:962182078449983508> Acesso negado! Você precisa de <@&984128716009508924> para utilizar esse comando\nCaso você tenha tente utilizar o comando em <#984128655879979028>`)
  vipbed.setTitle(`Acesso negado`)
  vipbed.setTimestamp()
  vipbed.setFooter(`Comando solicitado por ${message.author.tag}`, message.author.avatarURL({ dynamic: true }))
  if (message.channel.id !== "988769144285573130" && message.channel.id !== "986288365026541619") { return message.channel.send({embeds: [vipbed]}).then(async msg => {
    setTimeout(() => {
      message.delete(message)
      msg.delete(msg)
    }, 30000)
  })
                                                    }

  if (talkedRecently.has(message.author.id)) {
    message.reply(`Voce precisa esperar ${config.cooldown} minutos para usar esse comando novamente!`).then(m => {
      setTimeout(() => {
        m.delete(m)
      }, 15000); //5 seconds
    })
  } else {
    fs.readFile('./netflix.txt', function(err, data) {
      if (err) throw err;
      data = data + '';
      var lines = data.split('\n');
      let random = lines[Math.floor(Math.random() * lines.length)];
      if (random === "") {
        const stockbed = new Discord.MessageEmbed()
        stockbed.addField("Sem stock", `Estamos sem stock de \`\`netflix\`\` use o comando a!stock `)
        stockbed.setColor("#2F3136")
        message.channel.send({ embeds: [stockbed] })

        return
      }

      let hex = '#' + (Math.random() * 0xFFFFFF << 0).toString(16);
      const embed = new Discord.MessageEmbed()
      embed.addField(`netflix Alt`, `Aqui esta sua netflix Alt: \n${random}`)
      embed.setThumbnail("https://images-ext-1.discordapp.net/external/23HTyixRfAxEsohCVTjClMTjOJq5FQcwaX3MRI3sbzE/https/cdn.discordapp.com/emojis/953641785274560592.png")
      embed.setColor("ff0303")
      message.author.send({ embeds: [embed] }).catch(() => {
        message.channel.send(`${message.author} Eu não posso enviar Menssagem em sua direct message`).then(m => {
        setTimeout(() => {
          m.delete(m)
          message.delete(message)
        }, 5000);
        })//5 seconds
   return });

      const gembed = new Discord.MessageEmbed()
.setColor("2F3136")
.setDescription("Conta/key gerada e enviada verifique seu privado")
.setImage("https://media.discordapp.net/attachments/979439490735153222/988844287498276914/standard.gif")
.setFooter("Altsworld by: ! ᵠᵈʷsigs#7237 & DK'Izzy#0007 ", message.author.avatarURL({ dynamic: true }))
.setTimestamp()
      message.reply({ embeds: [gembed] }).then(m => {
        setTimeout(() => {
    message.delete(message)
        }, 15000)
      ; //5 seconds



        talkedRecently.add(message.author.id);
        setTimeout(() => {
          talkedRecently.delete(message.author.id);
        }, config.cooldown * 60 * 1000);

      })
          })

    
     
        }
        }