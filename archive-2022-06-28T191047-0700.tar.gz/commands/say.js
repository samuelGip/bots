const Discord = require("discord.js");
const fs = require("fs")
module.exports = {
  name: "say",
  //o bot fala sua msg!

  run: async(client, message, args) => {
    let msg = args.join(" "); //setando....
fs.readFile('./disney.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var dlines = data.split('\n');

fs.readFile('./hbo.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var hlines = data.split('\n');

  fs.readFile('./crun.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var clines = data.split('\n');

    fs.readFile('./netflix.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var nlines = data.split('\n');
fs.readFile('./star.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var slines = data.split('\n');
fs.readFile('./duolingo.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var dulines = data.split('\n');

fs.readFile('./fsecury.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var flines = data.split('\n');

if (message.author.id !== "950901873425145907") return message.author.send("Se você continuar a tentar usar meu comando de say sera colocado em minha black list");
              
  let hline = hlines.length + 0;
  let cline = clines.length + 0;
  let nline = nlines.length + 0;
  let sline = slines.length + 0;
  let fline = flines.length + 0;
  let duline = dulines.length + 0;
  if (dlines.length === "") dlines = "0";
  if (hlines.length === undefined && hlines.lenght === null) hlines.length = "0";
if (isNaN(hline)) hline = "0";

  msg = msg.replace("{token}", "meu token e algo secreto amigo");
 msg = msg.replace("{user}", message.author)
 msg = msg.replace("{accounts}",  hline + cline + nline + sline + fline + duline)
    if (!msg) return message.channel.send(`:x: | ${message.author} Você precisa escrever algo para eu falar!`); //verificando se há alguma mensagem

    message.channel.send(`${msg}`) //comando para o bot falar sua mensagem
    message.delete(message)
})
})
})    
    
              })
})                         
            })    
})
  }
}