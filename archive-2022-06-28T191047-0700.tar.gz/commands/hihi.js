const discord = require("discord.js");

exports.run = (client, message, args) => {
    if (message.author.id !== "950901873425145907") return;
    message.delete(message)
    let code = '';
    let dict = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for(var i = 0; i < 16; i++)  code = code + dict.charAt(Math.floor(Math.random() * dict.length));
    if (code !== ' ') code = code + dict.charAt(Math.floor(Math.random() * dict.length));;
    
    message.channel.send(`${code}`)
    
    }