const discord = require("discord.js");
const fs = require("fs")

exports.run = (client, message, args) => {

fs.readFile('./disney.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var dlines = data.split('\n');

fs.readFile('./hbo.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var hlines = data.split('\n');

  fs.readFile('./crun.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var clines = data.split('\n');

    fs.readFile('./netflix.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var nlines = data.split('\n');
fs.readFile('./star.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var slines = data.split('\n');
fs.readFile('./duolingo.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var dulines = data.split('\n');

fs.readFile('./fsecury.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var flines = data.split('\n');
fs.readFile('./paramount.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var plines = data.split('\n');
fs.readFile('./gmail.txt', function(err, data){
            if(err) throw err;
            data = data + '';
            var glines = data.split('\n');

  let pline = plines.length + 0;
  let hline = hlines.length + 0;
  let cline = clines.length + 0;
  let nline = nlines.length + 0;
  let sline = slines.length + 0;
  let fline = flines.length + 0;
  let duline = dulines.length + 0;
  let gline = glines.length + 0;
  if (dlines.length === "") dlines = "0";
  if (hlines.length === undefined && hlines.lenght === null) hlines.length = "0";
if (isNaN(hline)) hline = "0";
  const stockbed = new discord.MessageEmbed()
  .setTitle(`©️Copyright AltsWord`)

  .setDescription(`Disney: \`\`${dlines.length}\`\`\nHbo: \`\`${hline}\`\`\n Crunchyroll: \`\`${cline}\`\`\nStar+: \`\`${sline}\`\`\nNetflix: \`\`${nline}\`\`\nDuolingo: \`\`${duline}\`\`\nfsecury: \`\`${fline}\`\`\nParamount: \`\`${pline}\`\`\ngmail: \`\`${gline}\`\``)

  message.channel.send({embeds: [stockbed]})

              })
})                         
            })    
    
              })
})                         
            })    
      })
            })
})
}