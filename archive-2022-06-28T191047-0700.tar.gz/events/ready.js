const client = require("../index");

const { MessageEmbed } = require("discord.js")

client.on("ready", () => {

      let activities = [

      `❤️ AltsWords By: Sigs & DK'Izzy`

    ],

        i = 0;

      setInterval(() => {

        client.user.setActivity(`${activities[i++ % activities.length]}`, {

          type: `COMPETING`,

          $browser: 'Discord iOS',

        })

      }, 1000 * 10);

      

      const embed = new MessageEmbed()

          .setColor("2F3136")

         .addField("**[ACC CLIENT]**", "CONECTADO NA DATABASE (Atualmente com mais de 100 mil contas)")

        .addField("**[SHARDING]**", `Shard 0(cupcake) conectado em ${client.guilds.cache.size} servidores`)

      

      client.channels.cache.get("984482748997722142").send({ embeds: [embed]})

      client.channels.cache.get("989283634106212413").send({ embeds: [embed]})

})

      
      
      

      

          
      
      

