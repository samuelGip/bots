const Discord = require("discord.js")

module.exports = {
    name: "ticket",
    description: "[MOD] Abre um ticket no canal atual",
   type: "CHAT_INPUT",
   run: async(client, interaction, args) => {

        if (!interaction.member.permissions.has("ADMINISTRATOR")) {
            interaction.reply({content: `Você não possui permissão para utilizar este comando.`, ephemeral: true})
        } else {
            let embed = new Discord.MessageEmbed()
            .setColor("#2F3136")
            .setThumbnail(interaction.guild.iconURL({ dynamic: true }))
            .setFooter({ text: `${interaction.guild.name}` ,iconURL: interaction.guild.iconURL({ dynamic: true })})
            .setTimestamp(interaction.guild.createdAt.toLocaleDateString("pt-br"))
            .setDescription(`*Olá Está com dúvidas aqui na ${interaction.guild.name}?*,\n\n*Utilize o suporte para entrar em contato com os nossos staff aonde eles vão explicar tudo do nosso servidor!,\n\nReaja a baixo para obeter o seu ticket ${interaction.guild.name}*`)
            .setTitle(`\`🎁🎉 ${interaction.guild.name} Suporte\``);
            
            let botao = new Discord.MessageActionRow()
            .addComponents(
                new Discord.MessageButton()
                .setCustomId("sup")
                .setLabel("rewards")
                .setEmoji('<:settings:962181478190555138>')
                .setStyle("PRIMARY")
                .setDisabled(false),
              new Discord.MessageButton()
                .setCustomId("den")
                .setLabel("Denúncia")
                .setEmoji ('<a:emoji_2:961428569555361852>')
                .setStyle("PRIMARY")
                .setDisabled(true),
                new Discord.MessageButton()
                .setCustomId("com")
                .setLabel("Compras")
                .setEmoji ('<:Compras:971816616620875786> ')
                .setStyle("PRIMARY")
                .setDisabled(true),
);

            interaction.reply({ embeds: [embed], components: [botao] })
        }      
    }
} 