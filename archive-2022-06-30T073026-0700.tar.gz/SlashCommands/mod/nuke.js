



const Discord = require('discord.js');
const { Client, MessageEmbed } = require('discord.js');
const emoji = require ("../../emoji.json")
module.exports = {
    name: "nuke",
    description: "[🛠 Moderacao]nuke um canal",
  type: "CHAT_INPUT",

run: async (client, interaction, args) => {

  var perms = interaction.member.permissions.has("ADMINISTRATOR")
  if(!perms) { return interaction.reply({content: "O senhor nao tem permissao para usar este comando!", ephemeral: true }) }
if(!interaction.guild.me.permissions.has("ADMINISTRATOR")) return interaction.reply({content: `Eu nao tenho perm para isso!`});
if(!interaction.guild.me.permissions.has("ADMINISTRATOR")) return interaction.reply({content: `Eu nao tenho perm para isso!`});

  let link = "https://cdn.discordapp.com/attachments/786627691267751976/787745289523691541/6c485efad8b910e5289fc7968ea1d22f.gif"

  const nuke = new Discord.MessageAttachment(link, "nuke.gif")

  var posicion = interaction.channel.position
  
  interaction.channel.clone().then((canal) => {
    interaction.channel.delete()

    canal.setPosition(posicion)
let embed = new Discord.MessageEmbed()
    .setDescription(`${emoji.chat} Chat nuke, **${interaction.member}** explodiu o canal`)
    .setColor("#2F3136")
    .setImage(`https://media.discordapp.net/attachments/856202207522848799/888558356493631498/6Ip.gif`)
   .setTimestamp(Date.now())
  .setFooter({ text: `Comando usado por ${interaction.member.user.tag}`, iconURL: `${interaction.member.user.displayAvatarURL({ dynamic: true })}` })
      .setTimestamp()
    canal.send({ embeds: [embed]}).then(async msg => {
      setTimeout(() => {
        msg.delete(msg)
      }, 30000)
    })
  })



    
 }
 
}