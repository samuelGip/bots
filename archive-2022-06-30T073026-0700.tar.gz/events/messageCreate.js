const Discord = require ("discord.js")

exports.run = (client, message) => {

let botao = new MessageActionRow()
                  .addComponents(
                      new MessageButton()
                      .setLabel ("MEU SERVIDOR")
                      .setStyle("URL")
                      .setURL("https://discord.gg/VChwjgMV2Q")
                  );
  
     if (message.author.bot) return;
     if (message.channel.type == 'dm') return;
     if (!message.content.toLowerCase().startsWith(config.prefix.toLowerCase())) return;
     if (message.content.startsWith(`<@!${client.user.id}>`) || message.content.startsWith(`<@${client.user.id}>`)) {
     const mencionados = new Discord.MessageEmbed()
      .setColor('2F3136')
      .setDescription('Me compre falando com o meu criador **! ᵠᵈʷsigs#9999**')
      return message.channel.send(mencionados)
     
     
     }
    const args = message.content
        .trim().slice(config.prefix.length)
        .split(/ +/g);
    const command = args.shift().toLowerCase();

    try {
        const commandFile = require(`./commands/${command}.js`)
        commandFile.run(client, message, args);

const logbed = new MessageEmbed()
  .setDescription(`New log ${message.author.tag} usou meu comando \`\`a!${command}\`\`\nNo servidor: \`\`${message.guild.name}\`\`\nNo canal: <#${message.channelId}>`)
    .setColor("#2F3136")
        client.channels.cache.get(`984482748997722142`).send({embeds: [logbed]})
     
      
    } catch (err) {
    console.error('Erro:' + err);
  }
  
  }