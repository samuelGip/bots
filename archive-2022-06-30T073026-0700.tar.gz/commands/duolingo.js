const Discord = require("discord.js")
const fs = require("fs")
const config = require("../config.json")
const talkedRecently = new Set();

exports.run = (client, message, args) => {
   if (message.channel.id !== "988600406336737331" && message.channel.id !== "988768978421809222" && message.channel.id !== "988769144285573130" && message.channel.id !== "986288229227593748" && message.channel.id !== "986288307233239121" && message.channel.id !== "986288365026541619") { return message.delete(message) }

  if (talkedRecently.has(message.author.id)) {
    message.reply(`Voce precisa esperar ${config.cooldown} minutos para usar esse comando novamente!`).then(m => {
      setTimeout(() => {
        m.delete(m)
      }, 60000); //5 seconds
    })
  } else {
    fs.readFile('./duolingo.txt', function(err, data) {
      if (err) throw err;
      data = data + '';
      var lines = data.split('\n');
      let random = lines[Math.floor(Math.random() * lines.length)];
      if (random === "") {
        const stockbed = new Discord.MessageEmbed()
        stockbed.addField("Sem stock", `Estamos sem stock de \`\`duolingo\`\` use o comando a!stock `)
        stockbed.setColor("#2F3136")
        message.channel.send({ embeds: [stockbed] })

        return
      }

      let hex = '#' + (Math.random() * 0xFFFFFF << 0).toString(16);
      const embed = new Discord.MessageEmbed()
      embed.addField(`duolingo Alt`, `Aqui esta sua duolingo alt: \n${random}\n **[visite o meu servidor](https://discord.gg/VChwjgMV2Q)**`)
      embed.setThumbnail("https://media.discordapp.net/attachments/964334860116328458/986072050550603816/logo-with-duo.png")
      embed.setColor("#000001")
      message.author.send({ embeds: [embed] }).catch(() => {
        message.channel.send(`<@${message.author.id}> Eu não posso enviar Menssagem em sua direct message`).then(m => {
        setTimeout(() => {
          
        }, 5000);
        })//5 seconds
   return });

      const gembed = new Discord.MessageEmbed()
.setColor("2F3136")
.setDescription("Conta/key gerada e enviada verifique seu privado")
.setImage("https://media.discordapp.net/attachments/979439490735153222/988844287498276914/standard.gif")
.setFooter("Altsworld by: ! ᵠᵈʷsigs#7237 & DK'Izzy#0007 ", message.author.avatarURL({ dynamic: true }))
.setTimestamp()
      message.reply({ embeds: [gembed] }).then(m => {
        setTimeout(() => {
    message.delete(message)
        }, 15000)
      ; //5 seconds


        talkedRecently.add(message.author.id);
        setTimeout(() => {
          talkedRecently.delete(message.author.id);
        }, config.cooldown * 60 * 1000);

      })
          })
     
        }
        }