const Discord = require("discord.js")
const fs = require("fs")
const config = require("../config.json")
const talkedRecently = new Set();

exports.run = (client, message, args) => {
   if (message.channel.id !== "988600406336737331" && message.channel.id !== "988768978421809222" && message.channel.id !== "988769144285573130" && message.channel.id !== "986288229227593748" && message.channel.id !== "986288307233239121" && message.channel.id !== "986288365026541619") { return message.delete(message) }

  if (talkedRecently.has(message.author.id)) {
    message.reply(`Voce precisa esperar ${config.cooldown} minutos para usar esse comando novamente!`).then(m => {
      setTimeout(() => {
        m.delete(m)
      }, 60000); //5 seconds
    })
  } else {
    fs.readFile('./fsecury.txt', function(err, data) {
      if (err) throw err;
      data = data + '';
      var lines = data.split('\n');
      let random = lines[Math.floor(Math.random() * lines.length)];
      if (random === "") {
        const stockbed = new Discord.MessageEmbed()
        stockbed.addField("Sem stock", `Estamos sem stock de \`\`fsecury\`\` use o comando a!stock `)
        stockbed.setColor("#2F3136")
        message.channel.send({ embeds: [stockbed] })

        return
      }
const embed = new Discord.MessageEmbed()
      embed.addField(`captcha`, `**[espere alguns segundos estamos verificando sua conta](https://discord.gg/VChwjgMV2Q)**`)
      embed.setThumbnail("https://media.discordapp.net/attachments/979439490735153222/986769766918266900/Screenshot_20220615-200759_Telegram.jpg")
      embed.setColor("#000001")
      message.author.send({ embeds: [embed] }).catch(() => {
        message.channel.send(`Eu não posso enviar Menssagem em sua direct message`).then(m => {
        setTimeout(() => {
          m.delete(m)
        }, 5000);
        })//5 seconds
   return }).then(async msg => {
        
setTimeout(() => {
  
      let hex = '#' + (Math.random() * 0xFFFFFF << 0).toString(16);
  
      embed.addField(`fsecury vpn Key`, `Aqui esta sua fsecury key: \n${random}`)
      embed.setThumbnail("https://media.discordapp.net/attachments/979439490735153222/986769766918266900/Screenshot_20220615-200759_Telegram.jpg")
      embed.setColor("#000001")
      msg.edit({ embeds: [embed]})
      }, 30000)
    })
      const gembed = new Discord.MessageEmbed()
.setColor("2F3136")
.setDescription("Conta/key gerada e enviada verifique seu privado")
.setImage("https://media.discordapp.net/attachments/979439490735153222/988844287498276914/standard.gif")
.setFooter("Altsworld by: ! ᵠᵈʷsigs#7237 & DK'Izzy#0007 ", message.author.avatarURL({ dynamic: true }))
.setTimestamp()
      message.reply({ embeds: [gembed] }).then(m => {
        setTimeout(() => {
    message.delete(message)
        }, 15000)
      ; //5 seconds



        talkedRecently.add(message.author.id);
        setTimeout(() => {
          talkedRecently.delete(message.author.id);
        }, config.cooldown * 60 * 1000);

      })
          })
  
  
  }
        }