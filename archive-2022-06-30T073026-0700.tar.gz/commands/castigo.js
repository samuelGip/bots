
const ms = require("ms") //npm i --save ms
const { MessageEmbed } = require("discord.js")
module.exports.run = async (bot,message,args) => {
    if(!message.member.permissions.has("BAN_MEMBERS")) {
        return message.reply("Voce precisa da permissãode \"BAN_MEMBERS\"") //Se o membro não tiver permissão para usar o comando
    }

    if(!message.guild.me.permissions.has("BAN_MEMBERS")) {
        return message.reply("Eu preciso da permissãode \"BAN_MEMBERS\"") //Se o bot não tiver permissão para executar essa ação
    }

    if(args.length === 0) {
        const lengthEmbed = new MessageEmbed()
        .setColor("2F3136")
        .setDescription("Use: `!timeout <usuário> <tempo> <motivo>`")
        return message.reply({embeds: [lengthEmbed]})
    }

    const membro = message.mentions.members.first()
    const tempo = args[1]
    const motivo = args.slice(2).join(" ")
    
    message.delete()
    
    const tempoEmMs = ms(tempo)    
   
    const embed = new MessageEmbed()
    .setThumbnail(message.author.displayAvatarURL())
    .setColor("2F3136")
    .addFields(
        {name: '> Author do punimento ', value: `<@${message.author.id}>`, inline: true},
        {name: '> Motivo da punição ', value: `\`\`${motivo}\`\``, inline: true},
        {name: '> Tempo de punição ', value: `${tempo}`, inline: false},
        {name: '> Ação da punição ', value: `Silenciamento temporário`, inline: true},
    )
    if(membro.roles.rawPosition >= message.member.roles.rawPosition) {
        return message.reply("Você não pode punir um membro com cargo igual ou superior ao seu")
    } else {
        membro.timeout(tempoEmMs, motivo)
        bot.channels.cache.get("984482748997722142").send({embeds: [embed]})
    }
}