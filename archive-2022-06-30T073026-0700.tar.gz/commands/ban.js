const Discord = require("discord.js")

module.exports.run = async (client,message,args) => {
    if(!message.member.permissions.has("BAN_MEMBERS")) {
        return message.reply("Voce precisa da permissãode \"BAN_MEMBERS\"") //Se o membro não tiver permissão para usar o comando
    }

    if(!message.guild.me.permissions.has("BAN_MEMBERS")) {
        return message.reply("Voce precisa da permissãode \"BAN_MEMBERS\"") //Se o bot não tiver permissão para executar essa ação
    }

    const membro = message.mentions.members.first() //Pega o membro mencionado ou o membro com o ID passado
    if(!membro) return message.reply("Você não mencionou nenhum membro!") //Se não mencionar nenhum membro, vai aparecer essa mensagem

    const motivo = args.slice(1).join(" ") ?? "Sem motivo" //Pega o motivo do ban, se caso não estiver nada escrito vai aparecer esse "Sem motivo"
   message.delete(message)

    const banEmbed = new Discord.MessageEmbed()
    .setColor("2F3136")
    .setTitle("Usuário banido")
    .setDescription(`${membro.user.tag} foi banido por ${message.author.tag}`)
    .addField("> Motivo", motivo)
    client.channels.cache.get(`984482748997722142`).send({embeds: [banEmbed]}) //se caso quer que envie em algum canal especifico
  membro.ban() //Vai banir o membro mencionado e enviar o motivo
}
