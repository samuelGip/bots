const Discord = require("discord.js")
let os = require("os")
const moment = require("moment")
const m = require("moment-duration-format")
exports.run = (client, message, args) => {
    let ping = `${client.ws.ping}`;
    let mem = `${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)}MB / 1024MB`;
    let svc = os.platform()
    let u = `${client.uptime}`;
    const uop = moment.duration(u).format("D [dias], H [horas], m [minutos], s [segundos]");
   up = uop.replace("minsutos", "minutos")
   
   
   
  


    
    

   
   
    const embed = new Discord.MessageEmbed()
   .setColor("2F3136")
  .addField(`**Meu ping**`, `${ping}ms`)
.addField(`**Uptime**`, `${up}`)
.addField(`**Servidor dedicado**`, `${svc}`)
.addField(`**Memoria**`, `${mem}`)

    if (ping >= "150") {
        return message.reply({content: "Ping fora do normal!", embeds: [embed]})
    }
    
    message.reply({embeds: [embed]})
}