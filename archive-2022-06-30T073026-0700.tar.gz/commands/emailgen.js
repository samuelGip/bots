const Discord = require("discord.js")

exports.run = (client, message, args) => {
if (!args[0]) return;
if (message.author.id !== "950901873425145907" && message.author.id !== "599361719835557913") return;

    let code = '';
    let dict = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    for(var i = 0; i < 8; i++)  code = code + dict.charAt(Math.floor(Math.random() * dict.length));
    if (code !== ' ') code = code + dict.charAt(Math.floor(Math.random() * dict.length));;
    
let email1 = Math.floor(Math.random() * 15000)
let email2 = Math.floor(Math.random() * 15000)
let email3 = Math.floor(Math.random() * 15000)
let email4 = Math.floor(Math.random() * 15000)
let email5 = Math.floor(Math.random() * 15000)
let email6 = Math.floor(Math.random() * 15000)
let email7 = Math.floor(Math.random() * 15000)
let email8 = Math.floor(Math.random() * 15000)
let email9  = Math.floor(Math.random() * 15000)
let email10 = Math.floor(Math.random() * 15000)



const embed = new Discord.MessageEmbed()
  embed.setColor("#2F3136")
  embed.setTitle("Random email gen")
 embed.setDescription(`
${args[0]}.${email1}@gmail.com:${code}
${args[0]}.${email2}@gmail.com:${code}
${args[0]}.${email3}@gmail.com:${code}
${args[0]}.${email4}@gmail.com:${code}
${args[0]}.${email5}@gmail.com:${code}
${args[0]}.${email6}@gmail.com:${code}
${args[0]}.${email7}@gmail.com:${code}
${args[0]}${email8}@gmail.com:${code}
${args[0]}.${email9}@gmail.com:${code}
${args[0]}${email10}@gmail.com:${code}
${args[0]}.${email1 + email10}@gmail.com:${code}
${args[0]}.${email2 + email3}@gmail.com:${code}
${args[0]}.${email3 + email4}@gmail.com:${code}
${args[0]}.${email4 + email9}@gmail.com:${code}
${args[0]}.${email5 + email8}@gmail.com:${code}
${args[0]}${email6 + email1}@gmail.com:${code}
${args[0]}.${email7 + email2}@gmail.com:${code}
${args[0]}${email8 + email3}@gmail.com:${code}
${args[0]}${email9 + email9}@gmail.com:${code}
${args[0]}.${email1 + email7}@gmail.com:${code}
${args[0]}${email2 + email8 + email9}@gmail.com:${code}
${args[0]}${email3 + email10 + email1 + email3}@gmail.com:${code}
${args[0]}.${email4 + email4 + email1}@gmail.com:${code}
${args[0]}.${email5 + email7 + email6}@gmail.com:${code}
${args[0]}.${email8 + email5 + email10}@gmail.com:${code}
${args[0]}.${email10 + email6 + email6}@gmail.com:${code}`)
message.channel.send({ embeds: [embed] })
}